# -*- coding: utf-8 -*-

from GPR_algorithms import GPRs
from input_func import Data_Set
from output_func import Output_Main
